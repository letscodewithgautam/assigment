package f_assigment;

public class calculation {
public static void main(String[] args) {
	
	int x1 = (101 + 0)/3;
	System.out.println("(101 + 0)/3)->"+x1);
	
	double x2 = 3.0e-6 * 10000000.1;
	System.out.println("3.0e-6*10000000.1-> "+(x2));
	
	System.out.println("true && true -> "+ true);
	System.out.println("false && true -> "+ false);
	System.out.println("(false && false) || (true && true) -> "+ true);
	System.out.println("(false && false) || (true && true) -> "+ false);
}
}